# Color Grid Puzzle — Android project

A self-contained offline puzzle game.

Gameplay:
- 50 levels
- 3x3, 4x4 and 5x5 boards
- Tap a tile to toggle it and its four neighbours
- Guaranteed-solvable level generation
- Move counter
- Restart
- Level progression
- No internet permission required

Build:
1. Open this folder in Android Studio.
2. Allow Gradle sync.
3. Run on an Android device/emulator.
4. Build > Generate App Bundles or APKs.

For Google Play, the release build still needs:
- Your Play Console developer account
- Release signing key
- Store listing/icon/screenshots
- Privacy policy if applicable
- Data Safety declaration
- Content rating
- Current Play target/API requirements at the time of submission

The game itself is offline and contains no analytics, ads, login, or external network calls in this version.
