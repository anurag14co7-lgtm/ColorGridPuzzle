package com.colorgridpuzzle.app;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, board, content;
    TextView movesView, levelView;
    int level=1, moves=0, size=3;
    boolean[][] on;
    int purple=Color.rgb(103,80,164), dark=Color.rgb(35,32,40), bg=Color.rgb(250,247,255);

    TextView tv(String s,float sp){ TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(dark); t.setPadding(8,10,8,10); return t; }
    Button b(String s){ Button x=new Button(this); x.setText(s); x.setAllCaps(false); return x; }

    public void onCreate(Bundle x){super.onCreate(x); showMenu();}

    void base(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(24,20,24,20); root.setBackgroundColor(bg);
        setContentView(root);
    }

    void showMenu(){
        base();
        TextView logo=tv("COLOR GRID PUZZLE",28); logo.setTypeface(Typeface.DEFAULT,Typeface.BOLD); logo.setTextColor(purple);
        root.addView(logo);
        root.addView(tv("Switch every tile OFF to solve the puzzle.",17));
        Button play=b("▶  PLAY"); Button about=b("How to Play");
        root.addView(play,new LinearLayout.LayoutParams(-1,-2));
        root.addView(about,new LinearLayout.LayoutParams(-1,-2));
        TextView best=tv("50 handcrafted levels • No internet required",14); root.addView(best);
        play.setOnClickListener(v->startLevel(1));
        about.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("How to Play").setMessage("Tap a tile. It switches itself and its up/down/left/right neighbours. Turn every tile OFF to win. Fewer moves are better.").setPositiveButton("Got it",null).show());
    }

    void startLevel(int l){
        level=l; moves=0; size=(level<11?3:(level<31?4:5));
        on=new boolean[size][size];
        Random r=new Random(level*9973L);
        // Generate a guaranteed solvable board by applying random moves to all-off.
        int taps=Math.min(4+level*2,size*size*2);
        for(int i=0;i<taps;i++) toggle(r.nextInt(size),r.nextInt(size),false);
        drawGame();
    }

    void toggle(int r,int c,boolean count){
        int[][] d={{0,0},{1,0},{-1,0},{0,1},{0,-1}};
        for(int[] q:d){int a=r+q[0],z=c+q[1]; if(a>=0&&a<size&&z>=0&&z<size) on[a][z]=!on[a][z];}
        if(count){moves++; drawBoard();}
    }

    void drawGame(){
        base();
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        levelView=tv("Level "+level,20); levelView.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        movesView=tv("Moves: "+moves,16);
        top.addView(levelView,new LinearLayout.LayoutParams(0,-2,1)); top.addView(movesView);
        root.addView(top);
        board=new LinearLayout(this); board.setOrientation(LinearLayout.VERTICAL); board.setGravity(Gravity.CENTER);
        root.addView(board,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout actions=new LinearLayout(this);
        Button restart=b("↻ Restart"), menu=b("⌂ Menu");
        actions.addView(restart,new LinearLayout.LayoutParams(0,-2,1)); actions.addView(menu,new LinearLayout.LayoutParams(0,-2,1));
        root.addView(actions);
        restart.setOnClickListener(v->startLevel(level)); menu.setOnClickListener(v->showMenu());
        drawBoard();
    }

    void drawBoard(){
        board.removeAllViews();
        for(int r=0;r<size;r++){
            LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER);
            for(int c=0;c<size;c++){
                final int rr=r,cc=c;
                Button tile=b(on[r][c]?"●":"○");
                tile.setTextSize(size==5?22:30); tile.setTextColor(on[r][c]?Color.WHITE:Color.rgb(105,98,115));
                tile.setBackgroundColor(on[r][c]?purple:Color.rgb(230,225,236));
                LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(90,90); p.setMargins(5,5,5,5);
                row.addView(tile,p);
                tile.setOnClickListener(v->{toggle(rr,cc,true); if(solved()) win();});
            }
            board.addView(row);
        }
        movesView.setText("Moves: "+moves);
    }

    boolean solved(){for(int r=0;r<size;r++)for(int c=0;c<size;c++)if(on[r][c])return false;return true;}

    void win(){
        String msg="Solved in "+moves+" moves!";
        if(level>=50){
            new AlertDialog.Builder(this).setTitle("🎉 You finished!").setMessage(msg+"\nAll 50 levels complete.").setPositiveButton("Menu",(d,w)->showMenu()).show();
        }else{
            new AlertDialog.Builder(this).setTitle("🎉 Level Complete").setMessage(msg)
              .setNegativeButton("Menu",(d,w)->showMenu())
              .setPositiveButton("Next Level",(d,w)->startLevel(level+1)).show();
        }
    }
}
